import React from "react";
import { Link } from "react-router-dom"
import { useState, useEffect } from "react";
import './ListAllStudents.css';

export default function Liststudentloyee() {
    const [Students, setstudentloyees] = useState([]);
    useEffect(() => {
        fetch("http://localhost:8080/api/students/allStudents")
            .then((response) => response.json())
            .then((data) => {
                setstudentloyees(data);
                alert(data)
            });
    }, []);
    return (
        <div>
            <h2>Students Data...</h2>
            <table>
                <thead>
                    <tr>
                        <th>Student Id</th>
                        <th>Batch Id</th>
                        <th>Email</th>
                        <th>Enquiry Id</th>
                        <th>Fees Paid</th>
                        <th>Location Id</th>
                        <th>Contact No</th>
                        <th>Date of Birth</th>
                        <th>Course Id</th>
                        <th>Total Fees</th>
                        <th>Payment Id</th>
                        <th>Student Name</th>
                        <th>Gender</th>
                        <th>Photo</th>
                        <th>Qualification Id</th>
                        <th>Registration Date</th>
                    </tr>
                </thead>
                <tbody>
                    {Students.map((student) => (
                        <tr key={student.student_id}>
                            <td>{student.student_id}</td>
                            <td>{student.batch_id}</td>
                            <td>{student.email}</td>
                            <td>{student.enquiry_id}</td>
                            <td>{student.fees_paid}</td>
                            <td>{student.location_id}</td>
                            <td>{student.contact_no}</td>
                            <td>{student.date_of_birth}</td>
                            <td>{student.course_id}</td>
                            <td>{student.total_fees}</td>
                            <td>{student.payment_id}</td>
                            <td>{student.student_name}</td>
                            <td>{student.gender}</td>
                            <td>{student.photo}</td>  {/* Corrected from 'phto' to 'photo' */}
                            <td>{student.qualification_id}</td>
                            <td>{student.registration_date}</td>
                            <td><a href={'/studentup/' + student.student_id}>Edit</a></td>
                            <td><a href={'/delstud/' + student.student_id}>Delete</a></td>
                        </tr>
                    ))}
                </tbody>
            </table>

        </div>
    );
}