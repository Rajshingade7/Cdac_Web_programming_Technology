import './App.css';
import {Outlet, Link} from "react-router-dom"
import StudentUp from './StudentUp';


function App() {
  return (
    <div className="App">
      <nav>
        <ul>
          <li>
            <Link to="/Home" >Home</Link>
          </li>
          
          <li>
             <Link to="/ListAllStudents">List Students</Link>
          </li>
          <li><Link to="/addStudent">Add Students</Link></li>
        </ul>
      </nav>
      <Outlet></Outlet>
    </div>
  );
}

export default App;
