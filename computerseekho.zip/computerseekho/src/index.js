import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Home from './Home';
import reportWebVitals from './reportWebVitals';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import ListAllStudents from './ListAllStudents'
import AddStudent from './AddStudents'
import StudentUp from './StudentUp'
import Delstudent from './delete_student'

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
  <Routes>
  <Route path="/" element={<App/>}>
    <Route path="/Home"  element={<Home />}/>
    <Route path="ListAllStudents" element={<ListAllStudents/>}/>
    <Route path="addStudent" element={<AddStudent/>}/>
    <Route path="studentup/:id" element={<StudentUp/>}/>
    <Route path="delstud/:id" element={<Delstudent/>}/>
    </Route>
  </Routes>
  </BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
