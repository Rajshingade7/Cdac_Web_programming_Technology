import React from 'react';
import { useState, useEffect } from "react";
import { useParams,useNavigate } from "react-router-dom"
export function delete_student() {
    const [student, setstudent] = useState({});
    const { id } = useParams()
    const navigate= useNavigate();
    useEffect(() => {
        fetch("http://localhost:8080/api/students/" + id)
            .then(res => res.json())
            .then((result) => { setstudent(result); }
            );
    }, {});
    const handeldel = (event) => {
        fetch("http://localhost:8080/api/students/" + id, {
            method: 'Delete'
        })
            .then(res => res)
            .then((result) => {
                console.log(result)
            }); 
            navigate('/');
    }

    return (

        <div>
            <h1 style={{ color:'red' }}>R you sure U Want to delete complete record</h1>

            
            <form onSubmit={handeldel}>
                <input type="submit" />
            </form>
        </div>

    );
}
export default delete_student;
